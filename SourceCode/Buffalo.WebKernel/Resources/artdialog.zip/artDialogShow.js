﻿var _currentDialog = null; //当前弹出的框

function showIFrameDialog(url, title, heigth, width, isDialog, closeFn) {
    _currentDialog = art.dialog.open(url, { title: title, width: width, height: heigth, lock: isDialog,
        closeFn: closeFn
    });
}
//关闭当前对话框
function closeCurDialog() {
    if (_currentDialog != null) {
        _currentDialog.close();
    }
}
//关闭当前对话框
function artAlertDialog(title,content,isDialog) {
    _currentDialog = art.dialog(
        {
            title:title,
            content: content,
            lock: isDialog
        }
        );
}
